base=int(input("enter a value for base:"))
height=int(input("enter a value for height:"))
a=(base**2 + height**2)**0.5
print(a)

