numbers = list(map(int, input("enter numbers (comma-separated): ").split(',')))
result = sorted(numbers)
print("Sorted Numbers in Ascending Order:", result)
